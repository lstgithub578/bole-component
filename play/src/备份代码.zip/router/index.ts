import { createRouter, createWebHashHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    redirect: '/form'
  },
  {
    path: '/form',
    name: 'Form',
    component: () => import('@/views/form/index.vue')
  },
  {
    path: '/dialog',
    name: 'Dialog',
    component: () => import('@/views/dialog/index.vue')
  },
  {
    path: '/table',
    name: 'table',
    component: () => import('@/views/table/index.vue')
  },
  {
    path: '/layout',
    name: 'layout',
    component: () => import('@/views/layout/index.vue')
  },
  {
    path: '/form-validation',
    name: 'formValidation',
    component: () => import('@/views/formValidation/index.vue')
  },
  {
    path: '/el-form',
    name: 'elForm',
    component: () => import('@/views/elForm/index.vue')
  },
  {
    path: '/form-rules',
    name: 'formRules',
    component: () => import('@/views/form-rules/index.vue')
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
