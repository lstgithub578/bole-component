import type { TableArrayColumns, TableObjectColumns } from '@bole-component/components'
import { h } from 'vue'

export const options: TableArrayColumns = [
  {
    props: {
      type: 'selection'
    },
    show: () => false
  },
  {
    props: {
      label: 'btn'
    },
    buttons: [
      {
        label: '按钮',
        props: {
          type: 'success'
        },
        click(scope) {
          console.log('scope', scope)
        }
      }
    ]
  },
  {
    props: {
      label: '一层'
    },
    slot: 'one'
  },
  {
    props: {
      label: '标题',
      renderHeader() {
        return h('span', null, '111')
      },
      renderCell() {}
    },
    children: [
      {
        label: '嵌套1',
        prop: '111'
      },
      {
        props: {
          label: '嵌套2',
          prop: '111'
        },
        children: [
          {
            props: {
              label: '嵌套11',
              prop: '111'
            },
            slot: 'grade'
          },
          {
            props: {
              label: '嵌套22',
              prop: '111'
            },
            slot: 'test'
          },
          {
            props: {
              label: '嵌套3'
            },
            children: [
              {
                props: {
                  label: '嵌套4'
                },
                slot: 'test2'
              }
            ]
          }
        ]
      }
    ]
  }
]

export const options2: TableObjectColumns = {
  name: '用户名称',
  department: '部门',
  age: {
    props: {
      label: '年龄'
    }
  }
}
