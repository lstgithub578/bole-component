<script setup lang="ts">
import { BoTable } from '@bole-component/components'
import { options, options2 } from './tableOptions'
defineOptions({
  name: 'TableTest'
})
</script>

<template>
  <div>
    <BoTable
      :options="options"
      :action="{
        label: '操作',
        buttons: [
          {
            label: '修改',
            props: ({ $index }) => ({
              disabled: $index > 1,
              type: 'primary'
            }),
            click(scope) {
              console.log(scope)
            }
          },
          {
            label: '修改',
            props: ({ row }) => {
              return {
                disabled: true
              }
            }
          }
        ]
      }"
    >
    </BoTable>

    <bo-table :options="options2"></bo-table>
  </div>
</template>

<style scoped></style>
