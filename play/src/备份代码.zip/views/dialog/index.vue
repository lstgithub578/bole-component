<script setup lang="ts">
import { ref } from 'vue'
import { BoDialog, DialogInstance, BoForm } from '@bole-component/components'
import { formFields1 } from './formFields'
import { ElInput } from 'element-plus'
import { useRouter } from 'vue-router'

defineOptions({
  name: 'DialogIndex'
})

const dialog = ref<DialogInstance>()
const addDialog = ref<DialogInstance>()

const router = useRouter()

function openDialog() {
  dialog.value?.open({
    title: '测试',
    height: '80%',
    width: '65%',
    confirmBtnText: '提交',
    setFormData: (callBack: Function) => {
      callBack((form: any) => {
        form.getAsyncData(['cate2', 'cate3'])
      })
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve({
            remark: '这是一段测试的文字',
            cate1: 4,
            cate2: 6,
            cate3: 20
          })
        }, 3000)
      })
    },
    // setFormData: {
    //   remark: '这是一段测试的文字',
    //   cate1: 4,
    //   cate2: 6,
    //   cate3: 20
    // },
    confirm: ({ data, close, loading, stopLoading }) => {
      loading()

      setTimeout(() => {
        stopLoading()
      }, 3000)
    },
    cancel({ close }) {
      close()
    }
  })
}

function addOrEditCate() {
  addDialog.value?.open({
    setFormData: null
  })
}
</script>

<template>
  <div>
    <BoDialog
      ref="dialog"
      :dialogProps="{
        alignCenter: true
      }"
      :getAsyncDataWhenEveryOpen="false"
    >
      <!-- <template #header>
        <div style="height: 190px">111</div>
      </template> -->
      <BoForm
        class="w-full"
        :options="formFields1"
        :formProps="{
          labelWidth: '100px'
        }"
        :model="{ name: 'luct' }"
      >
        <template #slot="{ formData }">
          <ElInput v-model="formData.slot"></ElInput>
        </template>
        <template #addCate3>
          <ElButton type="primary" size="small" @click="addOrEditCate()">添加种类</ElButton>
        </template>
      </BoForm>
    </BoDialog>

    <BoDialog ref="addDialog">
      <BoForm
        :options="formFields1"
        :formProps="{
          labelWidth: '100px'
        }"
        :model="{ name: 'luct' }"
      >
        <template #slot="{ formData }">
          <ElInput v-model="formData.slot"></ElInput>
        </template>
        <!-- <template #addCate3>
          <ElButton type="primary" size="small">添加元器件</ElButton>
        </template> -->
      </BoForm>
    </BoDialog>
    <ElButton type="primary" @click="openDialog">打开对话框</ElButton>

    <el-button @click="router.push('/form')">form</el-button>
  </div>
</template>

<style scoped></style>
