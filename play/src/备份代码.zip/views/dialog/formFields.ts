import type { FormObjectOptions } from '@bole-component/components'
import testApi from '@/api/testApi'

export const formFields1: FormObjectOptions = {
  name: '名称',
  remark: {
    label: '备注',
    type: 'input',
    props: {
      type: 'textarea'
    }
  },
  cate1: {
    label: '三级联动',
    type: 'select',
    asyncData: () => testApi.getTree(0),
    event: ({ getAsyncData, clearComponentData }) => {
      return {
        change: (val: any) => {
          val && getAsyncData('cate2')
          clearComponentData(['cate2', 'cate3'])
        }
      }
    },
    valueGetter: (item) => item.id,
    labelGetter: (item) => item.name,
    colProps: { span: 9 }
  },
  cate2: {
    label: '',
    type: 'select',
    asyncData: ({ formData }: any) => testApi.getTree(formData.cate1),
    event: ({ getAsyncData, clearComponentData }) => {
      return {
        change: (val: any) => {
          val && getAsyncData(['cate3'])
          clearComponentData(['cate3'])
        }
      }
    },
    valueGetter: (item) => item.id,
    labelGetter: (item) => item.name,
    colProps: { span: 6 }
  },
  cate3: {
    label: '',
    type: 'select',
    asyncData: ({ formData }: any) => testApi.getTree(formData.cate2),
    valueGetter: (item) => item.id,
    labelGetter: (item) => item.name,
    colProps: { span: 6 }
  },
  addCate3: {
    label: '',
    type: 'slot',
    colProps: { span: 3 }
  },
  date: {
    label: '日期',
    type: 'date',
    props: {
      type: 'datetime',
      startPlaceholder: '开始日期',
      endPlaceholder: '结束日期',
      valueFormat: 'YYYY-MM-DD HH:mm:ss',
      format: 'YYYY-MM-DD HH:mm:ss'
    }
  },
  slot: {
    label: '插槽',
    type: 'slot'
  }
}
