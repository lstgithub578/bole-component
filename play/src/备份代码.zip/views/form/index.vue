<script lang="ts" setup>
import { ref } from 'vue'
import { type FormInstance, BoForm } from '@bole-component/components'
import { options } from './formOptions'

defineOptions({
  name: 'FormPlay'
})

const form = ref<FormInstance>()

function setFormData() {
  form.value!.setData({
    id: '1233434',
    input1: '1111'
  })
}

function getFormData() {
  form.value!.getData().then(
    (formData: Record<string, any>) => {
      console.log('获取到的表单数据', formData)
    },
    (err: any) => {
      console.log(err)
    }
  )
}
</script>

<template>
  <div class="container">
    <BoForm
      ref="form"
      :options="options"
      :rules="{
        input2: [{ required: true, message: '内容必填' }]
      }"
      :model="{ input1: '123', radio1: 1 }"
    ></BoForm>

    <ElButton type="success" @click="setFormData">设置表单数据</ElButton>
    <ElButton type="primary" @click="getFormData">获取表单数据</ElButton>
    <ElButton @click="form?.resetData()">重置</ElButton>
  </div>
</template>
<style scoped>
.container {
  width: 60%;
}
</style>
