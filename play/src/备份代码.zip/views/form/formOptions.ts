import type { FormObjectOptions } from '@bole-component/components'
import { h } from 'vue'
import { Search } from '@element-plus/icons-vue'
import { ElIcon } from 'element-plus'

export const options: FormObjectOptions = {
  input1: '输入框1',
  input2: {
    label: '输入框2',
    type: 'input',
    slots() {
      return {
        prefix: h(ElIcon, { size: 20 }, [h(Search)])
      }
    },
    append() {
      return h('div', { style: { marginLeft: '0.5em' } }, '米')
    }
  },
  pwdInput: {
    label: '密码输入框',
    type: 'input'
  },
  number: { label: '数字输入框', type: 'number', props: {} },
  select1: {
    label: '下拉框1',
    type: 'select',
    asyncData: () =>
      Promise.resolve({
        data: [
          { name: '男', id: 0 },
          { name: '女', id: 1 },
          { name: '未知', id: 2 }
        ]
      }),
    valueGetter: (data: any) => data.id,
    labelGetter: (data: any) => data.name
  },
  select2: {
    label: '下拉框2',
    type: 'select',
    data: ['男', '女', '未知']
  },
  select3: {
    label: '下拉框3',
    type: 'select',
    data: {
      0: '男',
      1: '女',
      2: '未知'
    }
  },
  radio1: {
    label: '单选1',
    type: 'radio',
    data: [
      { name: '男', id: 0 },
      { name: '女', id: 1 },
      { name: '未知', id: 2 }
    ],
    valueGetter: (item: any) => item.id,
    labelGetter: (item: any) => item.name
  },
  radio2: {
    label: '单选2',
    type: 'radio',
    data: ['男', '女', '未知']
  },
  radio3: {
    label: '单选3',
    type: 'radio',
    data: {
      0: '男',
      1: '女',
      2: '未知'
    },
    valueGetter: (item) => item
  },
  checkbox: {
    type: 'checkbox',
    button: true,
    data: ['a', 'b', 'c']
  },
  cascader: {
    label: '级联选择器',
    type: 'cascader',
    data: [
      {
        value: 'guide',
        label: 'Guide',
        children: [
          {
            value: 'disciplines',
            label: 'Disciplines',
            children: [
              {
                value: 'consistency',
                label: 'Consistency'
              },
              {
                value: 'feedback',
                label: 'Feedback'
              },
              {
                value: 'efficiency',
                label: 'Efficiency'
              },
              {
                value: 'controllability',
                label: 'Controllability'
              }
            ]
          },
          {
            value: 'navigation',
            label: 'Navigation',
            children: [
              {
                value: 'side nav',
                label: 'Side Navigation'
              },
              {
                value: 'top nav',
                label: 'Top Navigation'
              }
            ]
          }
        ]
      },
      {
        value: 'component',
        label: 'Component',
        children: [
          {
            value: 'basic',
            label: 'Basic',
            children: [
              {
                value: 'layout',
                label: 'Layout'
              },
              {
                value: 'color',
                label: 'Color'
              },
              {
                value: 'typography',
                label: 'Typography'
              },
              {
                value: 'icon',
                label: 'Icon'
              },
              {
                value: 'button',
                label: 'Button'
              }
            ]
          },
          {
            value: 'form',
            label: 'Form',
            children: [
              {
                value: 'radio',
                label: 'Radio'
              },
              {
                value: 'checkbox',
                label: 'Checkbox'
              },
              {
                value: 'input',
                label: 'Input'
              },
              {
                value: 'input-number',
                label: 'InputNumber'
              },
              {
                value: 'select',
                label: 'Select'
              },
              {
                value: 'cascader',
                label: 'Cascader'
              },
              {
                value: 'switch',
                label: 'Switch'
              },
              {
                value: 'slider',
                label: 'Slider'
              },
              {
                value: 'time-picker',
                label: 'TimePicker'
              },
              {
                value: 'date-picker',
                label: 'DatePicker'
              },
              {
                value: 'datetime-picker',
                label: 'DateTimePicker'
              },
              {
                value: 'upload',
                label: 'Upload'
              },
              {
                value: 'rate',
                label: 'Rate'
              },
              {
                value: 'form',
                label: 'Form'
              }
            ]
          },
          {
            value: 'data',
            label: 'Data',
            children: [
              {
                value: 'table',
                label: 'Table'
              },
              {
                value: 'tag',
                label: 'Tag'
              },
              {
                value: 'progress',
                label: 'Progress'
              },
              {
                value: 'tree',
                label: 'Tree'
              },
              {
                value: 'pagination',
                label: 'Pagination'
              },
              {
                value: 'badge',
                label: 'Badge'
              }
            ]
          },
          {
            value: 'notice',
            label: 'Notice',
            children: [
              {
                value: 'alert',
                label: 'Alert'
              },
              {
                value: 'loading',
                label: 'Loading'
              },
              {
                value: 'message',
                label: 'Message'
              },
              {
                value: 'message-box',
                label: 'MessageBox'
              },
              {
                value: 'notification',
                label: 'Notification'
              }
            ]
          },
          {
            value: 'navigation',
            label: 'Navigation',
            children: [
              {
                value: 'menu',
                label: 'Menu'
              },
              {
                value: 'tabs',
                label: 'Tabs'
              },
              {
                value: 'breadcrumb',
                label: 'Breadcrumb'
              },
              {
                value: 'dropdown',
                label: 'Dropdown'
              },
              {
                value: 'steps',
                label: 'Steps'
              }
            ]
          },
          {
            value: 'others',
            label: 'Others',
            children: [
              {
                value: 'dialog',
                label: 'Dialog'
              },
              {
                value: 'tooltip',
                label: 'Tooltip'
              },
              {
                value: 'popover',
                label: 'Popover'
              },
              {
                value: 'card',
                label: 'Card'
              },
              {
                value: 'carousel',
                label: 'Carousel'
              },
              {
                value: 'collapse',
                label: 'Collapse'
              }
            ]
          }
        ]
      },
      {
        value: 'resource',
        label: 'Resource',
        children: [
          {
            value: 'axure',
            label: 'Axure Components'
          },
          {
            value: 'sketch',
            label: 'Sketch Templates'
          },
          {
            value: 'docs',
            label: 'Design Documentation'
          }
        ]
      }
    ]
  },
  remark: {
    label: '备注',
    type: 'input',
    props: {
      type: 'textarea'
    }
  },
  test: {
    type: 'number',
    props: {}
  }
}
