<script setup lang="ts">
import { ElForm, ElFormItem, ElButton, type FormInstance } from 'element-plus'
import { reactive } from 'vue'
import { ref } from 'vue'
const form = ref<FormInstance>()

const formData = reactive({
  id: '1',
  username: '张三',
  password: '',
  confirmPassword: ''
})
defineOptions({
  name: 'ElFormTest'
})

function reset() {
  form.value?.resetFields()
  console.log('formData', formData)
}
</script>

<template>
  <div>
    <ElForm ref="form" :model="formData">
      <el-form-item label="名称" prop="usename">
        <el-input v-model="formData.username"></el-input>
      </el-form-item>
      <el-form-item label="密码" prop="password">
        <el-input v-model="formData.password"></el-input>
      </el-form-item>
      <el-form-item label="确认密码" prop="confirmPassword">
        <el-input v-model="formData.confirmPassword"></el-input>
      </el-form-item>
    </ElForm>
    <el-button @click="reset">重置</el-button>
  </div>
</template>
