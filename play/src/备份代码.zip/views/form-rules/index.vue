<script setup lang="ts">
import { BoForm, type FormOptions } from '@bole-component/components'
import type { FormRules } from 'element-plus'
defineOptions({
  name: 'FormRules'
})

const formOptions: FormOptions = {
  username: '用户名',
  password: '密码',
  confirmPassword: '确认密码'
}

const formRules = (): FormRules => {
  console.log('更新了')
  return {
    username: { required: true, message: '请输入用户名' },
    password: { required: true, message: '请输入密码' },
    confirmPassword: { required: true, message: '请输入确认密码' }
  }
}
</script>

<template>
  <div>
    <BoForm :options="formOptions" :rules="formRules"></BoForm>
  </div>
</template>
